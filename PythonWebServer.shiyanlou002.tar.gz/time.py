from datetime import datetime
print('''\
        <html>
        <body>
        <p>Generated {0}</p>
        </body>
        </html>'''.format(datetime.now()))
